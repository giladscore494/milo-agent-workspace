MILO R5 source capture
======================

Capture id     : milo-r5-source-capture-20260914T161110Z
Overall status : ready_for_r5_bundle_review
Requests       : 11
Gov records    : 466
manifest.json  : sha256 3c48a4d8545f5ab6404e4573920c0c1b18c9d5bea0da04cf79fea3c840ca309f

What this archive is
--------------------
Byte-exact bodies of a fixed, bounded set of public read-only HTTP GET
requests, captured server-side by the MILO R5 Streamlit capture app.
Government JSON and Toyota HTML under raw/ are stored exactly as received.
Nothing there was pretty-printed, normalized, renamed or rewritten.

raw/ versus derived/
--------------------
raw/      Exact response bytes, one file per HTTP request. This is the
          evidence. Every hash in manifest.json and SHA256SUMS.txt is
          taken over these bytes.
derived/  Deterministic consolidations built by this tool from the raw
          pages: all records for one resource, deduplicated by original
          _id only, in first-seen order, with per-record provenance
          naming the query and raw page it came from. Field names and
          values are preserved verbatim. No vehicle fact is invented,
          normalized or inferred.

Pagination
----------
  additional   q=RAV4                   pages=3    reported_total=233      captured=233
  wltp         q=RAV4                   pages=3    reported_total=233      captured=233

Authentication
--------------
None. Every source is a public endpoint. No API key, access token,
username, password, cookie or Authorization header was used or stored.

Preserved headers
-----------------
Only these response headers are retained: Date, Content-Type, Content-Length, Content-Encoding, ETag, Last-Modified, Location, Cache-Control, Retry-After.
Set-Cookie, Cookie, Authorization and Proxy-Authorization are never
retained, and no cookie is ever replayed between requests.

Verifying this archive
----------------------
From the archive root directory:

    sha256sum -c SHA256SUMS.txt

SHA256SUMS.txt covers manifest.json, README.txt and every raw and derived
file. It cannot list its own digest; compare manifest.json against the
sha256 printed above instead.

Toyota evidence: what it does and does not establish
---------------------------------------------------
The previous URL https://www.toyota.co.il/models/rav4-plugin
returned HTTP 404 and was replaced by the official Toyota Israel archive
pages. A result of
'passed_official_archived_model_identity_requires_human_fact_check'
means the saved HTML corroborates MODEL IDENTITY (Toyota, RAV4, Plug-in /
PHEV) and ARCHIVED STATUS (marketing of the model has ended). It is NOT a
technical specification and NOT a vehicle fact. No specification value was
extracted, and nothing was inferred from the URL or the filename.
Government CKAN data under raw/government/ remains the structured
technical source. A human must read the preserved HTML to confirm any
claim about the model.

Status meanings
---------------
ready_for_r5_bundle_review
    All mandatory Government requests passed, targeted Government records
    are present, both official Toyota pages passed, and integrity verified.
no_matching_government_records
    Government requests were valid but the targeted searches found no
    RAV4 candidates.
incomplete_official_web_source
    Government capture succeeded but a Toyota page was unavailable or
    failed validation.
capture_failed
    A network, HTTP, redirect, size, JSON, pagination or integrity failure
    prevented a valid capture.
